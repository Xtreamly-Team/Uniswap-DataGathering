import { FeeAmount } from '@uniswap/v3-sdk';
import { USDT_TOKEN, WETH_TOKEN } from './constants.js';
// Example Configuration
export const CurrentConfig = {
    rpc: {
        mainnet: 'https://mainnet.infura.io/v3/e2af5b5511974dc7aa9328736b0a9dbc',
    },
    tokens: {
        in: WETH_TOKEN,
        out: USDT_TOKEN,
        amountIn: 1,
        poolFee: FeeAmount.MEDIUM,
    },
};
//# sourceMappingURL=config.js.map